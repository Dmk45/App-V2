package com.mycompany.project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
