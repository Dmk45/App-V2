import '/flutter_flow/flutter_flow_util.dart';
import 'sett_widget.dart' show SettWidget;
import 'package:flutter/material.dart';

class SettModel extends FlutterFlowModel<SettWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
