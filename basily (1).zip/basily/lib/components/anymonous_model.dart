import '/flutter_flow/flutter_flow_util.dart';
import 'anymonous_widget.dart' show AnymonousWidget;
import 'package:flutter/material.dart';

class AnymonousModel extends FlutterFlowModel<AnymonousWidget> {
  ///  Local state fields for this component.

  bool fade = false;

  bool fade2 = false;

  ///  State fields for stateful widgets in this component.

  // State field(s) for MouseRegion widget.
  bool mouseRegionHovered1 = false;
  // State field(s) for MouseRegion widget.
  bool mouseRegionHovered2 = false;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
