export 'get_streamed_response_http.dart'
    if (dart.library.js) 'get_streamed_response_web.dart'
    if (dart.library.js_interop) 'get_streamed_response_web.dart';
